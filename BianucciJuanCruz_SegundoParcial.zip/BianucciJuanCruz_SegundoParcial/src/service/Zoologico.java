package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Zoologico<T extends CSVserializable> implements Inventariable<T>
{

    List<T> lista = new ArrayList<T>();
    
    @Override
    public void agregar(T item) 
    {
        lista.add(item);
    }

    @Override
    public T obtener(int indice) 
    {
        return lista.get(indice);
    }

    @Override
    public void eliminar(int indice) 
    {
        lista.remove(indice);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) 
    {
        List<T> toReturn = new ArrayList<>();
        for (T item:lista)
        {
            if (predicado.test(item))
                {
                    toReturn.add(item);
                }
        }
        
        return toReturn;
    }

    @Override
    public void ordenar() 
    {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparador) 
    {
        lista.sort(comparador);
    }

    @Override
    public void guardarEnArchivo(String path)throws IOException, ClassNotFoundException
    {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path)){})
        {
            salida.writeObject(lista);
        }
        
    }


    @Override
    public void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException 
    {
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path)))
        {
            lista = (List<T>)entrada.readObject();
            
        }
    }

    @Override
    public void guardarEnCSV(String path) throws IOException
    {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter (path)))
        {
            bw.write("id,nombre,especie,alimentacion\n");            
        
            for (T a : lista)
            {
                bw.write(a.toCSV() + "\n");
            }
        } 
     
        
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> funcion) throws IOException 
    {
        lista.clear();
        try (BufferedReader br = new BufferedReader(new FileReader (path)))
        {
            String linea;
            br.readLine();
            while((linea = br.readLine()) != null)
            {
                lista.add(funcion.apply(linea));
                
            }
        }
        
    }

    @Override
    public void paraCadaElemento(Consumer<T> consumer) 
    {
        for (T item : lista)
        {
          consumer.accept((item));
        }
    }
    
    
}
