package service;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Inventariable<T extends CSVserializable> 
{
    void agregar(T item);
    
    T obtener(int indice);
    
    void eliminar(int indice);
    
    List<T> filtrar(Predicate<T> predicado);
    
    void ordenar();
    
    void ordenar (Comparator<T> comparador);

    void guardarEnArchivo (String path) throws IOException, ClassNotFoundException;
    
    void cargarDesdeArchivo(String path) throws IOException, ClassNotFoundException;

    void guardarEnCSV (String path) throws IOException;
    
    void cargarDesdeCSV (String path, Function<String, T> funcion)throws IOException;

    void paraCadaElemento (Consumer<T> consumer);
}
