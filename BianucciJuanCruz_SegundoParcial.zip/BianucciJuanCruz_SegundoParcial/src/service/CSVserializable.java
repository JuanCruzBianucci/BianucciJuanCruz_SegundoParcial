
package service;


public interface CSVserializable 
{
    String toCSV();
    
}
